var o=(o,r)=>{const t=o.__vccOpts||o;for(const[c,s]of r)t[c]=s;return t};export{o as _};
